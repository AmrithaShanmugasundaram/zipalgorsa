package io.project.transaction_service.kafka;

import io.project.transaction_service.models.Transaction;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class TransactionConsumer {

    @KafkaListener(topics = "transaction-events", groupId = "transaction-group")
    public void consumeTransactionEvent(Transaction transaction) {
        System.out.println("Received transaction event: " + transaction);
        // Process the transaction event (e.g., update the database, trigger notifications)
    }
}