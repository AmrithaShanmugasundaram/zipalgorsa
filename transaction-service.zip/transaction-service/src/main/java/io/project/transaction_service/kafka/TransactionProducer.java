package io.project.transaction_service.kafka;

import io.project.transaction_service.models.Transaction;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class TransactionProducer {

    private final KafkaTemplate<String, Transaction> kafkaTemplate;
    private static final String TOPIC = "transaction-events";

    public TransactionProducer(KafkaTemplate<String, Transaction> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishTransactionEvent(Transaction transaction) {
        kafkaTemplate.send(TOPIC, transaction);
        System.out.println("Published transaction event: " + transaction);
    }
}