package io.project.transaction_service.models;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)  // Ensures transId is unique and required
    private String transId;

    private String accId; // Account ID

    private String userId; // Changed from int to String

    private double amount;

    private String status;

    @Column(updatable = false)  // Ensures date is set only once
    private LocalDateTime date;  // Changed from String to LocalDateTime

    // ✅ Automatically set the date when a new Transaction is created
    @PrePersist
    protected void onCreate() {
        if (this.date == null) {  
            this.date = LocalDateTime.now();
        }
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getAccId() {
		return accId;
	}

	public void setAccId(String accId) {
		this.accId = accId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public Transaction(Long id, String transId, String accId, String userId, double amount, String status,
			LocalDateTime date) {
		super();
		this.id = id;
		this.transId = transId;
		this.accId = accId;
		this.userId = userId;
		this.amount = amount;
		this.status = status;
		this.date = date;
	}

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
    
}
