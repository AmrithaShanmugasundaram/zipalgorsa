package io.project.transaction_service.services;

import io.project.transaction_service.models.Transaction;
import io.project.transaction_service.repository.TransactionRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    public Transaction addTransaction(Transaction transaction) {
        if (transaction.getTransId() != null && transactionRepository.findByTransId(transaction.getTransId()).isPresent()) {
            throw new IllegalArgumentException("Transaction with transId " + transaction.getTransId() + " already exists.");
        }
        return transactionRepository.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public List<Transaction> addMultipleTransactions(List<Transaction> transactions) {
        return transactionRepository.saveAll(transactions);
    }

    // ✅ Fetch transaction by transId
    public Optional<Transaction> getTransactionByTransId(String transId) {
        return transactionRepository.findByTransId(transId);
    }

    // ✅ Fetch transactions by userId (Fix for the missing method error)
    public List<Transaction> getTransactionsByUserId(String userId) {
        return transactionRepository.findByUserId(userId);
    }

    // ✅ Delete transaction by transId
    @Transactional
    public boolean deleteTransaction(String transId) {
        if (transactionRepository.findByTransId(transId).isPresent()) {
            transactionRepository.deleteByTransId(transId);
            return true;
        }
        return false;
    }
}
