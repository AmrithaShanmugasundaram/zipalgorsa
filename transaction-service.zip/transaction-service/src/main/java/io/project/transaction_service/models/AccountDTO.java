package io.project.transaction_service.models;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AccountDTO {
    private int accId;
    private String accType;
    private String status;
    private String createdDate;
    private String balance;
}