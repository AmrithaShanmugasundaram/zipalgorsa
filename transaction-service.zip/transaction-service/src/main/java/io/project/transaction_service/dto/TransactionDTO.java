package io.project.transaction_service.dto;

public class TransactionDTO {
    private Long transactionId;  // Ensure this matches the API response field name
    private Double amount;
    private String transactionType;
    private String transactionDate;

    // Constructor
    public TransactionDTO(Long transactionId, Double amount, String transactionType, String transactionDate) {
        this.transactionId = transactionId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.transactionDate = transactionDate;
    }

    // Getters and Setters
    public Long getTransactionId() { return transactionId; }
    public void setTransactionId(Long transactionId) { this.transactionId = transactionId; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public String getTransactionType() { return transactionType; }
    public void setTransactionType(String transactionType) { this.transactionType = transactionType; }

    public String getTransactionDate() { return transactionDate; }
    public void setTransactionDate(String transactionDate) { this.transactionDate = transactionDate; }
}
