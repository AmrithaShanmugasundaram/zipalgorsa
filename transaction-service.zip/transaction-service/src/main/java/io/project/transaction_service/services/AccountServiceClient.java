package io.project.transaction_service.services;

import io.project.transaction_service.models.AccountDTO;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AccountServiceClient {

    private final RestTemplate restTemplate;

    public AccountServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public AccountDTO getAccountById(String accId) {
        String url = "http://localhost:8081/accounts/" + accId; // 👈 Replace with Account-Service URL
        return restTemplate.getForObject(url, AccountDTO.class);
    }
}