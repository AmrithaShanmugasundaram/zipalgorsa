package io.project.transaction_service.controller;

import io.project.transaction_service.models.Transaction;
import io.project.transaction_service.services.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {
    
    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // ✅ Create a transaction
    @PostMapping("/add")
    public ResponseEntity<Transaction> createTransaction(@RequestBody Transaction transaction) {
        try {
            Transaction savedTransaction = transactionService.addTransaction(transaction);
            return ResponseEntity.ok(savedTransaction);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    // ✅ Fetch all transactions
    @GetMapping("/all")
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        List<Transaction> transactions = transactionService.getAllTransactions();
        return transactions.isEmpty()
            ? ResponseEntity.status(HttpStatus.NO_CONTENT).build()
            : ResponseEntity.ok(transactions);
    }

    // ✅ Fetch transaction by transId
    @GetMapping("/{transId}")
    public ResponseEntity<Transaction> getTransactionByTransId(@PathVariable String transId) {
        return transactionService.getTransactionByTransId(transId)
            .map(ResponseEntity::ok)
            .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    // ✅ Delete transaction by transId
    @DeleteMapping("/{transId}")
    public ResponseEntity<String> deleteTransaction(@PathVariable String transId) {
        boolean deleted = transactionService.deleteTransaction(transId);
        return deleted
            ? ResponseEntity.ok("Transaction deleted successfully.")
            : ResponseEntity.status(HttpStatus.NOT_FOUND).body("Transaction not found.");
    }

    // ✅ Fetch transactions by userId (NEWLY ADDED)
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Transaction>> getTransactionsByUserId(@PathVariable String userId) {
        List<Transaction> transactions = transactionService.getTransactionsByUserId(userId);
        return transactions.isEmpty()
            ? ResponseEntity.status(HttpStatus.NOT_FOUND).build()
            : ResponseEntity.ok(transactions);
    }
}
