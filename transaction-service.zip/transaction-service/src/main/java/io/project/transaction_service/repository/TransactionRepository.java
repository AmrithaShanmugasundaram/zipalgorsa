package io.project.transaction_service.repository;

import io.project.transaction_service.models.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TransactionRepository extends JpaRepository<Transaction, String> {
    Optional<Transaction> findByTransId(String transId);
    
    // ✅ Add this method to fix the error
    List<Transaction> findByUserId(String userId);
    
    void deleteByTransId(String transId);
}
