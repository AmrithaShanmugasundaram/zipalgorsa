package io.project.user_service.models;

import java.util.List;

import io.project.user_service.dtos.AccountResponse;
import io.project.user_service.dtos.TransactionResponse;

public class UserDetailsResponse {
    private Long id;
    private String authId;
    private String email;
    private String name;
    private String userId;
    private String contactNo;
    private String gender;
    private String nationality;
    private List<AccountResponse> accounts;
    private List<TransactionResponse> transactions;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAuthId() {
		return authId;
	}
	public void setAuthId(String authId) {
		this.authId = authId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public List<AccountResponse> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<AccountResponse> accounts) {
		this.accounts = accounts;
	}
	public List<TransactionResponse> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<TransactionResponse> transactions) {
		this.transactions = transactions;
	}
	public UserDetailsResponse(Long id, String authId, String email, String name, String userId, String contactNo,
			String gender, String nationality, List<AccountResponse> accounts, List<TransactionResponse> transactions) {
		super();
		this.id = id;
		this.authId = authId;
		this.email = email;
		this.name = name;
		this.userId = userId;
		this.contactNo = contactNo;
		this.gender = gender;
		this.nationality = nationality;
		this.accounts = accounts;
		this.transactions = transactions;
	}
	public UserDetailsResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

    
    // ✅ Getters and Setters (if needed)
}
