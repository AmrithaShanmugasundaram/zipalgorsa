package io.project.user_service.models;

public class UserItem {
	private String userfName;
	private String userlName;
	private String gender;
	private String address;
	private String nationality;
	public String getUserfName() {
		return userfName;
	}
	public void setUserfName(String userfName) {
		this.userfName = userfName;
	}
	public String getUserlName() {
		return userlName;
	}
	public void setUserlName(String userlName) {
		this.userlName = userlName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public UserItem(String userfName, String userlName, String gender, String address, String nationality) {
		super();
		this.userfName = userfName;
		this.userlName = userlName;
		this.gender = gender;
		this.address = address;
		this.nationality = nationality;
	}
	public UserItem() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}	