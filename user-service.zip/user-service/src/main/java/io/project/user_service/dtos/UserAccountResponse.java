package io.project.user_service.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.project.user_service.models.User;
import java.util.List;

public class UserAccountResponse {
    @JsonProperty("user")
    private User user;

    @JsonProperty("accounts")
    private List<AccountResponse> accounts;

    @JsonProperty("transactions")
    private List<TransactionResponse> transactions;

    // Default constructor
    public UserAccountResponse() {}

    public UserAccountResponse(User user, List<AccountResponse> accounts, List<TransactionResponse> transactions) {
        this.user = user;
        this.accounts = accounts;
        this.transactions = transactions;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<AccountResponse> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<AccountResponse> accounts) {
        this.accounts = accounts;
    }

    public List<TransactionResponse> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<TransactionResponse> transactions) {
        this.transactions = transactions;
    }
}