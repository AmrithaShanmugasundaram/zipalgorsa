package io.project.user_service.services;

import io.project.user_service.dtos.AccountResponse;
import io.project.user_service.dtos.TransactionResponse;
import io.project.user_service.dtos.UserAccountResponse;
import io.project.user_service.exceptions.UserServiceException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Service
public class PdfGenerationService {

    private static final String LOGO_PATH = "images/logo.png"; // Path to logo in resources

    public ByteArrayInputStream generatePdf(UserAccountResponse userResponse) throws UserServiceException, IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);

            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            // Add logo at the top left
            ClassPathResource logoResource = new ClassPathResource(LOGO_PATH);
            PDImageXObject pdImage = PDImageXObject.createFromFile(logoResource.getFile().getAbsolutePath(), document);
            contentStream.drawImage(pdImage, 50, 700, 100, 100); // x, y, width, height

            // Add title below the logo
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 20);
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 650); // Adjusted y position to avoid overlap with logo
            contentStream.showText("User Report");
            contentStream.endText();

            // User details
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 600);
            contentStream.showText("User Details:");
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("ID: " + userResponse.getUser().getId());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Auth ID: " + userResponse.getUser().getAuthId());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Email: " + userResponse.getUser().getEmail());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Name: " + userResponse.getUser().getName());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("User ID: " + userResponse.getUser().getUserId());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Contact No: " + userResponse.getUser().getContactNo());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Gender: " + userResponse.getUser().getGender());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Nationality: " + userResponse.getUser().getNationality());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Account ID: " + userResponse.getUser().getAccountId());
            contentStream.newLineAtOffset(0, -15);
            contentStream.showText("Transaction IDs: " + String.join(", ", userResponse.getUser().getTransactionIds()));
            contentStream.endText();

            // Accounts table
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 400);
            contentStream.showText("Accounts:");
            contentStream.endText();
            float tableTop = 380;
            float margin = 50;
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, tableTop);
            contentStream.showText("Account ID");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("User ID");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Account Type");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Balance");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Status");
            contentStream.endText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            float yStart = tableTop - 20;
            for (AccountResponse account : userResponse.getAccounts()) {
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, yStart);
                contentStream.showText(account.getAccountId());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(account.getUserId());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(account.getAccountType());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(String.valueOf(account.getBalance()));
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(account.getStatus());
                contentStream.endText();
                yStart -= 15;
            }

            // Transactions table
            contentStream.beginText();
            contentStream.newLineAtOffset(50, yStart - 20);
            contentStream.showText("Transactions:");
            contentStream.endText();
            float transTop = yStart - 40;
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(margin, transTop);
            contentStream.showText("Transaction ID");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Account ID");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("User ID");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Amount");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Status");
            contentStream.newLineAtOffset(100, 0);
            contentStream.showText("Date");
            contentStream.endText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            float transYStart = transTop - 20;
            for (TransactionResponse transaction : userResponse.getTransactions()) {
                contentStream.beginText();
                contentStream.newLineAtOffset(margin, transYStart);
                contentStream.showText(transaction.getTransactionId());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(transaction.getAccountId());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(transaction.getUserId());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(String.valueOf(transaction.getAmount()));
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(transaction.getStatus());
                contentStream.newLineAtOffset(100, 0);
                contentStream.showText(transaction.getDate() != null ? transaction.getDate().toString() : "N/A");
                contentStream.endText();
                transYStart -= 15;
            }

            contentStream.close();
            document.save(out);
        } catch (IOException e) {
            throw new UserServiceException("Failed to generate PDF due to IO error", e);
        }

        return new ByteArrayInputStream(out.toByteArray());
    }
}