package io.project.user_service.services;

import io.project.user_service.clients.AccountClient;
import io.project.user_service.clients.TransactionClient;
import io.project.user_service.config.JwtUtil;
import io.project.user_service.dtos.UserAccountResponse;
import io.project.user_service.exceptions.UserServiceException;
import io.project.user_service.models.User;
import io.project.user_service.repositories.UserRepository;
import io.project.user_service.dtos.AccountResponse;
import io.project.user_service.dtos.TransactionResponse;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final TransactionClient transactionClient;
    private final AccountClient accountClient;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Autowired
    private PdfGenerationService pdfGenerationService;
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    public UserService(UserRepository userRepository, TransactionClient transactionClient,
                       AccountClient accountClient, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.transactionClient = transactionClient;
        this.accountClient = accountClient;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    public record ApiResponse<T>(String status, T data, String message) {}

    // Create a new user
    public ResponseEntity<ApiResponse<UserAccountResponse>> createUser(User user) {
        logger.info("Creating new user with userId: {}", user.getUserId());

        if (userRepository.findByUserId(user.getUserId()).isPresent()) {
            logger.warn("User ID already exists: {}", user.getUserId());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse<>("error", null, "User ID already exists"));
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        User savedUser = userRepository.save(user);

        logger.info("User created successfully: {}", user.getUserId());
        UserAccountResponse responseData = new UserAccountResponse(savedUser, Collections.emptyList(), Collections.emptyList());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>("success", responseData, null));
    }

    // Fetch user details including accounts and transactions
    public ResponseEntity<ApiResponse<UserAccountResponse>> getUserByUserId(String userId) {
        logger.info("Fetching user details for userId: {}", userId);

        Optional<User> userOptional = userRepository.findByUserId(userId);
        if (userOptional.isEmpty()) {
            logger.warn("User not found: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponse<>("error", null, "User not found"));
        }

        User user = userOptional.get();
		List<AccountResponse> accountResponses = fetchAccounts(userId);
		logger.debug("Fetched accounts: {}", accountResponses);
		List<TransactionResponse> transactions = fetchTransactions(userId);
		logger.debug("Fetched transactions: {}", transactions);

		// Populate accountId and transactionIds in the User object
		if (!accountResponses.isEmpty()) {
		    user.setAccountId(accountResponses.get(0).getAccountId()); // Set first account ID
		}
		if (!transactions.isEmpty()) {
		    user.setTransactionIds(new HashSet<>(transactions.stream()
		            .map(TransactionResponse::getTransactionId)
		            .toList())); // Set set of transaction IDs
		}

		UserAccountResponse responseData = new UserAccountResponse(user, accountResponses, transactions);
		return ResponseEntity.ok(new ApiResponse<>("success", responseData, "User fetched successfully"));
    }

    // Get all users with pagination
    public ResponseEntity<ApiResponse<List<UserAccountResponse>>> getAllUsers(int page, int size) {
        logger.info("Fetching users, page: {}, size: {}", page, size);

        Page<User> users = userRepository.findAll(PageRequest.of(page, size));
        if (users.isEmpty()) {
            logger.warn("No users found.");
            return ResponseEntity.status(HttpStatus.OK)
                    .body(new ApiResponse<>("success", Collections.emptyList(), "No users found"));
        }

        logger.info("Fetched {} users", users.getTotalElements());
        List<UserAccountResponse> responseData = users.getContent().stream()
                .map(user -> new UserAccountResponse(user, Collections.emptyList(), Collections.emptyList()))
                .toList();
        return ResponseEntity.ok(new ApiResponse<>("success", responseData, null));
    }

    // Delete user by userId
    public ResponseEntity<ApiResponse<String>> deleteUser(String userId) {
        logger.info("Deleting user with userId: {}", userId);

        Optional<User> userOptional = userRepository.findByUserId(userId);
        if (userOptional.isEmpty()) {
            logger.warn("User not found: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponse<>("error", null, "User not found"));
        }

        userRepository.delete(userOptional.get());
        logger.info("User deleted successfully: {}", userId);
        return ResponseEntity.ok(new ApiResponse<>("success", null, "User deleted successfully"));
    }

    // Update existing user by userId
    public ResponseEntity<ApiResponse<UserAccountResponse>> updateUser(String userId, User updatedUser) {
        logger.info("Updating user with userId: {}", userId);

        Optional<User> userOptional = userRepository.findByUserId(userId);
        if (userOptional.isEmpty()) {
            logger.warn("User not found: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponse<>("error", null, "User not found"));
        }

        User existingUser = userOptional.get();

        // Validate inputs
        if (updatedUser.getEmail() != null && !updatedUser.getEmail().matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            logger.warn("Invalid email format for userId: {}", userId);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse<>("error", null, "Invalid email format"));
        }

        // Update fields
        if (updatedUser.getName() != null) {
            existingUser.setName(updatedUser.getName());
        }
        if (updatedUser.getEmail() != null) {
            existingUser.setEmail(updatedUser.getEmail());
        }

        User savedUser = userRepository.save(existingUser);
        logger.info("User updated successfully: {}", userId);
        UserAccountResponse responseData = new UserAccountResponse(savedUser, fetchAccounts(userId), fetchTransactions(userId));
        return ResponseEntity.ok(new ApiResponse<>("success", responseData, null));
    }

    // Login Method
    public ResponseEntity<ApiResponse<Map<String, String>>> login(String email, String password) throws Exception {
        logger.info("Attempting login for user");

        Optional<User> userOptional = userRepository.findByEmail(email);
        if (userOptional.isEmpty()) {
            logger.warn("Invalid email");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse<>("error", null, "Invalid email or password"));
        }

        User user = userOptional.get();
        if (!passwordEncoder.matches(password, user.getPassword())) {
            logger.warn("Invalid password");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse<>("error", null, "Invalid email or password"));
        }

        logger.info("Login successful");
        String token = jwtUtil.generateToken(email);
        return ResponseEntity.ok(new ApiResponse<>("success", Collections.singletonMap("token", token), "token created"));
    }

    // Helper Method: Fetch Account Details
    private List<AccountResponse> fetchAccounts(String userId) {
        try {
            logger.debug("Calling Account Service for userId: {}", userId);
            List<AccountResponse> accounts = accountClient.getAccountsByUserId(userId);
            logger.debug("Raw accounts response: {}", accounts);
            if (accounts != null) {
                for (AccountResponse account : accounts) {
                    if (account.getAccountId() == null) {
                        logger.warn("AccountId is null for userId: {}, generating fallback", userId);
                        account.setAccountId("ACC" + (accounts.indexOf(account) + 1));
                    }
                    if (account.getAccountType() == null) {
                        logger.warn("AccountType is null for userId: {}, setting default", userId);
                        account.setAccountType("Savings"); // Default type
                    }
                }
            }
            return accounts != null ? accounts : Collections.emptyList();
        } catch (Exception e) {
            logger.error("Error fetching accounts for userId: {}, error: {}", userId, e.getMessage(), e);
            return Collections.emptyList(); // Return empty list on failure
        }
    }

    // Helper Method: Fetch Transaction Details
    private List<TransactionResponse> fetchTransactions(String userId) {
        try {
            logger.debug("Calling Transaction Service for userId: {}", userId);
            List<TransactionResponse> transactions = transactionClient.getTransactionsByUser(userId);
            logger.debug("Raw transactions response: {}", transactions);
            if (transactions != null) {
                for (TransactionResponse transaction : transactions) {
                    if (transaction.getTransactionId() == null) {
                        logger.warn("TransactionId is null for userId: {}, generating fallback", userId);
                        transaction.setTransactionId("TXN" + (transactions.indexOf(transaction) + 1));
                    }
                    if (transaction.getAccountId() == null) {
                        logger.warn("AccountId is null for userId: {}, generating fallback", userId);
                        transaction.setAccountId("ACC" + (transactions.indexOf(transaction) + 1));
                    }
                }
            }
            return transactions != null ? transactions : Collections.emptyList();
        } catch (Exception e) {
            logger.error("Error fetching transactions for userId: {}, error: {}", userId, e.getMessage(), e);
            return Collections.emptyList(); // Return empty list on failure
        }
    }

    public ResponseEntity<byte[]> generateUserPdf(String userId) throws IOException, UserServiceException {
        logger.info("Generating PDF for userId: {}", userId);

        Optional<User> userOptional = userRepository.findByUserId(userId);
        if (userOptional.isEmpty()) {
            logger.warn("User not found: {}", userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        }

        try {
            User user = userOptional.get();
            List<AccountResponse> accountResponses = fetchAccounts(userId);
            List<TransactionResponse> transactions = fetchTransactions(userId);

            if (!accountResponses.isEmpty()) {
                user.setAccountId(accountResponses.get(0).getAccountId());
            } else {
                logger.warn("No accounts found for userId: {}, using fallback", userId);
                user.setAccountId("N/A");
            }

            if (!transactions.isEmpty()) {
                user.setTransactionIds(new HashSet<>(transactions.stream()
                        .map(TransactionResponse::getTransactionId)
                        .toList()));
            } else {
                logger.warn("No transactions found for userId: {}", userId);
                user.setTransactionIds(new HashSet<>());
            }

            UserAccountResponse userResponse = new UserAccountResponse(user, accountResponses, transactions);
            ByteArrayInputStream pdfStream = pdfGenerationService.generatePdf(userResponse);

            if (pdfStream == null) {
                logger.error("PDF generation returned null stream for userId: {}", userId);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(null);
            }

            byte[] pdfBytes = pdfStream.readAllBytes();
            if (pdfBytes.length == 0) {
                logger.warn("Generated PDF is empty for userId: {}", userId);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Empty PDF generated".getBytes());
            }

            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", "attachment; filename=user_report_" + userId + ".pdf");
            headers.setContentType(MediaType.APPLICATION_PDF);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(pdfBytes);
        } catch (IOException e) {
            logger.error("IO error generating PDF for userId: {}, error: {}", userId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("IO Error generating PDF: " + e.getMessage()).getBytes());
        }
    }
}