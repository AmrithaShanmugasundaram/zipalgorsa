package io.project.user_service.config;

import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component; // Added import

@Component // Added annotation to make JwtUtil a Spring-managed bean
public class JwtUtil {
    private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);
    private static final long EXPIRATION_TIME = 3600000; // 1 hour
    private static RSAPrivateKey privateKey;
    private static RSAPublicKey publicKey;

    static {
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048);
            KeyPair keyPair = keyGen.generateKeyPair();
            privateKey = (RSAPrivateKey) keyPair.getPrivate();
            publicKey = (RSAPublicKey) keyPair.getPublic();
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate RSA key pair", e);
        }
    }

    private static String base64UrlEncode(String input) {
        return Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(input.getBytes());
    }

    private static String base64UrlDecode(String input) {
        return new String(Base64.getUrlDecoder().decode(input));
    }

    private static String customRsaSign(String data) {
        try {
            byte[] dataBytes = data.getBytes();
            BigInteger dataInt = new BigInteger(1, dataBytes);
            BigInteger modulus = privateKey.getModulus();
            BigInteger exponent = privateKey.getPrivateExponent();
            BigInteger signatureInt = dataInt.modPow(exponent, modulus);
            return base64UrlEncode(signatureInt.toString());
        } catch (Exception e) {
            throw new RuntimeException("RSA signing failed", e);
        }
    }

    private static boolean customRsaVerify(String data, String signature) {
        try {
            BigInteger signatureInt = new BigInteger(base64UrlDecode(signature));
            BigInteger modulus = publicKey.getModulus();
            BigInteger exponent = publicKey.getPublicExponent();
            BigInteger recoveredInt = signatureInt.modPow(exponent, modulus);
            byte[] recoveredBytes = recoveredInt.toByteArray();
            byte[] originalBytes = data.getBytes();
            if (recoveredBytes.length > originalBytes.length) {
                recoveredBytes = Arrays.copyOfRange(recoveredBytes, recoveredBytes.length - originalBytes.length, recoveredBytes.length);
            }
            return Arrays.equals(recoveredBytes, originalBytes);
        } catch (Exception e) {
            logger.error("RSA verification failed: {}", e.getMessage(), e);
            return false;
        }
    }

    public static String generateToken(String email) throws Exception {
        String header = "{\"alg\":\"RSA\",\"typ\":\"JWT\"}";
        String encodedHeader = base64UrlEncode(header);

        long nowMillis = System.currentTimeMillis();
        long expMillis = nowMillis + EXPIRATION_TIME;
        String payload = String.format("{\"sub\":\"%s\",\"iat\":%d,\"exp\":%d}", email, nowMillis / 1000, expMillis / 1000);
        String encodedPayload = base64UrlEncode(payload);

        String unsignedToken = encodedHeader + "." + encodedPayload;
        String signature = customRsaSign(unsignedToken);

        return encodedHeader + "." + encodedPayload + "." + signature;
    }

    public static String extractUsername(String token) throws Exception {
        String[] parts = token.split("\\.");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid JWT token");
        }

        String unsignedToken = parts[0] + "." + parts[1];
        if (!customRsaVerify(unsignedToken, parts[2])) {
            throw new SecurityException("Invalid signature");
        }

        String payload = base64UrlDecode(parts[1]);
        try {
            JSONObject jsonPayload = new JSONObject(payload);
            return jsonPayload.getString("sub");
        } catch (Exception e) {
            logger.error("Failed to parse JWT payload: {}", e.getMessage(), e);
            throw new IllegalArgumentException("Invalid JWT payload", e);
        }
    }

    public static boolean validateToken(String token, UserDetails userDetails) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3) {
                logger.warn("Invalid JWT token: incorrect number of parts");
                return false;
            }

            String unsignedToken = parts[0] + "." + parts[1];
            if (!customRsaVerify(unsignedToken, parts[2])) {
                logger.warn("Invalid JWT signature");
                return false;
            }

            String payload = base64UrlDecode(parts[1]);
            JSONObject jsonPayload = new JSONObject(payload);
            long exp = jsonPayload.getLong("exp");
            long now = System.currentTimeMillis() / 1000;
            if (now > exp) {
                logger.warn("JWT token expired: exp={}, now={}", exp, now);
                return false;
            }

            String username = jsonPayload.getString("sub");
            if (!username.equals(userDetails.getUsername())) {
                logger.warn("JWT username mismatch: token={}, userDetails={}", username, userDetails.getUsername());
                return false;
            }

            boolean isValid = userDetails.isEnabled() && userDetails.isAccountNonExpired() &&
                    userDetails.isAccountNonLocked() && userDetails.isCredentialsNonExpired();
            if (!isValid) {
                logger.warn("User account is not valid: enabled={}, expired={}, locked={}, credsExpired={}",
                        userDetails.isEnabled(), userDetails.isAccountNonExpired(),
                        userDetails.isAccountNonLocked(), userDetails.isCredentialsNonExpired());
            }
            return isValid;
        } catch (Exception e) {
            logger.error("JWT validation failed: {}", e.getMessage(), e);
            return false;
        }
    }
}