package io.project.user_service.clients;

import io.project.user_service.dtos.AccountResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "account-service", url = "http://localhost:8081")
public interface AccountClient {

    @GetMapping("/accounts/user/{userId}")
    List<AccountResponse> getAccountsByUserId(@PathVariable("userId") String userId);
}
