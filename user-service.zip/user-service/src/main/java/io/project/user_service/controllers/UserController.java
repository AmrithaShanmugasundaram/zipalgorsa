package io.project.user_service.controllers;

import io.project.user_service.config.JwtUtil;
import io.project.user_service.dtos.LoginRequest;
import io.project.user_service.dtos.UserAccountResponse;
import io.project.user_service.exceptions.UserServiceException;
import io.project.user_service.models.User;
import io.project.user_service.services.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

record ApiResponse<T>(String status, T data, String message) {}

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = {"http://localhost:3000"})
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;

    public UserController(
            UserService userService,
            JwtUtil jwtUtil,
            AuthenticationManager authenticationManager,
            PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<io.project.user_service.services.UserService.ApiResponse<UserAccountResponse>>> createUser(@Valid @RequestBody User user) {
        logger.info("Creating user with email: {}", user.getEmail());
        ResponseEntity<io.project.user_service.services.UserService.ApiResponse<UserAccountResponse>> response = userService.createUser(user);
        return ResponseEntity.ok(new ApiResponse<>("success", response.getBody(), null));
    }

    @PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<Map<String, String>>> login(@Valid @RequestBody LoginRequest loginRequest) throws Exception {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getEmail(),
                            loginRequest.getPassword()
                    )
            );
            logger.info("User logged in successfully: {}", loginRequest.getEmail());
            String token = jwtUtil.generateToken(loginRequest.getEmail());
            return ResponseEntity.ok(new ApiResponse<>("success", Collections.singletonMap("token", token), "token created"));
        } catch (BadCredentialsException ex) {
            logger.error("Invalid login attempt for email: {}", loginRequest.getEmail());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ApiResponse<>("error", null, "Invalid email or password"));
        }
    }

    @GetMapping(value = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<io.project.user_service.services.UserService.ApiResponse<UserAccountResponse>> getUserByUserId(@PathVariable String userId) {
        logger.info("Fetching user with ID: {}", userId);
        ResponseEntity<io.project.user_service.services.UserService.ApiResponse<UserAccountResponse>> response = userService.getUserByUserId(userId);
        return response; // Directly return the service response
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<io.project.user_service.services.UserService.ApiResponse<List<UserAccountResponse>>>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        logger.info("Fetching all users, page: {}, size: {}", page, size);
        ResponseEntity<io.project.user_service.services.UserService.ApiResponse<List<UserAccountResponse>>> response = userService.getAllUsers(page, size);
        return ResponseEntity.ok(new ApiResponse<>("success", response.getBody(), null));
    }

    @DeleteMapping(value = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<String>> deleteUser(@PathVariable String userId) {
        logger.info("Deleting user with ID: {}", userId);
        ResponseEntity<?> response = userService.deleteUser(userId);
        return ResponseEntity.ok(new ApiResponse<>("success", null, "User deleted"));
    }

    @PutMapping(value = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<io.project.user_service.services.UserService.ApiResponse<UserAccountResponse>>> updateUser(
            @PathVariable String userId, @Valid @RequestBody User user) {
        logger.info("Updating user with ID: {}", userId);
        ResponseEntity<io.project.user_service.services.UserService.ApiResponse<UserAccountResponse>> response = userService.updateUser(userId, user);
        return ResponseEntity.ok(new ApiResponse<>("success", response.getBody(), null));
    }

    @PostMapping(value = "/encode-password", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse<String>> encodePassword(@RequestBody Map<String, String> request) {
        String password = request.get("password");
        String encodedPassword = passwordEncoder.encode(password);
        return ResponseEntity.ok(new ApiResponse<>("success", encodedPassword, null));
    }

    @GetMapping(value = "/{userId}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generateUserPdf(@PathVariable String userId) {
        logger.info("Generating PDF for userId: {}", userId);
        try {
            ResponseEntity<byte[]> response = userService.generateUserPdf(userId);
            if (response.getStatusCode() == HttpStatus.NOT_FOUND || response.getBody() == null) {
                logger.warn("PDF generation failed for userId: {}, returning not found", userId);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("User not found or PDF generation failed".getBytes());
            }
            return response;
        } catch (UserServiceException e) {
            logger.error("Service error generating PDF for userId: {}, error: {}", userId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("Error generating PDF: " + e.getMessage()).getBytes());
        } catch (IOException e) {
            logger.error("IO error generating PDF for userId: {}, error: {}", userId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("IO Error generating PDF: " + e.getMessage()).getBytes());
        }
    }
}