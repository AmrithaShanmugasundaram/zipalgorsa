package io.project.user_service.clients;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import io.project.user_service.dtos.TransactionResponse;

import java.util.List;

@FeignClient(name = "transaction-service", url = "http://localhost:8082") // Change URL if needed
public interface TransactionClient {
    @GetMapping("/transactions/user/{userId}")
    List<TransactionResponse> getTransactionsByUser(@PathVariable("userId") String userId);
}