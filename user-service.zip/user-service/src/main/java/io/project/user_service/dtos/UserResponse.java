package io.project.user_service.dtos;

import io.project.user_service.models.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {
    private String userId;
    private String authId;
    private String name;
    private String email;
    private String contactNo;
    private String gender;
    private String nationality;

    // Constructor to directly convert from Entity
    public UserResponse(User user) {
        this.userId = user.getUserId();
        this.authId = user.getAuthId();
        this.name = user.getName();
        this.email = user.getEmail();
        this.contactNo = user.getContactNo();
        this.gender = user.getGender();
        this.nationality = user.getNationality();
    }

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAuthId() {
		return authId;
	}

	public void setAuthId(String authId) {
		this.authId = authId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
    
}
