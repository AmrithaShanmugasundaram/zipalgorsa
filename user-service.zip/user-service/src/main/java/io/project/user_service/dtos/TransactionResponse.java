package io.project.user_service.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionResponse {

    @JsonProperty("transactionId")
    @NotNull(message = "Transaction ID cannot be null")
    private String transactionId;

    @JsonProperty("accountId")
    private String accountId;

    @JsonProperty("userId")
    private String userId;

    @JsonProperty("amount")
    @NotNull(message = "Amount cannot be null")
    private Double amount;

    @JsonProperty("status")
    private String status;

    @JsonProperty("date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime date;

    // Explicitly added getter for transactionId to resolve the undefined method error
    public String getTransactionId() {
        return transactionId;
    }

    // Explicitly added setter for transactionId (optional, but included for consistency)
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

	public String getAccountId() {
		return accountId;
	}
	
	public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId=userId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount=amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status=status;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
}